scoreboard players operation mod Temp = instrukcja Temp
scoreboard players operation mod Temp %= 2 Temp
$execute if score mod Temp matches 0 run setblock ~$(x) ~$(wysokosc) ~-$(z) air
$execute if score mod Temp matches 1 run setblock ~$(x) ~$(wysokosc) ~-$(z) minecraft:repeater[facing=$(orientacja)]
scoreboard players operation instrukcja Temp /= 2 Temp
scoreboard players add wysokosc Temp 2
execute store result storage minecraft:temp wysokosc int 1 run scoreboard players get wysokosc Temp
execute unless score wysokosc Temp matches 35 run function kampo:ustaw_instrukcje with storage minecraft:temp