execute store result storage minecraft:temp linijka int 1 run scoreboard players get linijka Temp
function kampo:oblicz_pozycje with storage minecraft:temp
scoreboard players add linijka Temp 1
execute if score linijka Temp matches 0..127 run function kampo:ustaw_program