$scoreboard players operation instrukcja Temp = $(linijka) $(program)
scoreboard players set wysokosc Temp 1
execute store result storage minecraft:temp wysokosc int 1 run scoreboard players get wysokosc Temp


$scoreboard players set x Temp $(linijka)
$scoreboard players set z Temp $(linijka)

scoreboard players operation x Temp %= 16 Temp
scoreboard players operation x Temp *= 2 Temp

scoreboard players operation z Temp /= 16 Temp
scoreboard players operation mod Temp = z Temp
scoreboard players operation mod Temp %= 2 Temp
execute if score mod Temp matches 0 run scoreboard players operation z Temp *= 5 Temp
execute if score mod Temp matches 1 run scoreboard players remove z Temp 1 
execute if score mod Temp matches 1 run scoreboard players operation z Temp *= 5 Temp
execute if score mod Temp matches 1 run scoreboard players add z Temp 2

execute if score mod Temp matches 0 run data modify storage minecraft:temp orientacja set value south
execute if score mod Temp matches 1 run data modify storage minecraft:temp orientacja set value north

execute store result storage minecraft:temp z int 1 run scoreboard players get z Temp
execute store result storage minecraft:temp x int 1 run scoreboard players get x Temp
function kampo:ustaw_instrukcje with storage minecraft:temp